"use client"

import { Sidebar } from "@/components/dashboard/sidebar"
import { TopNav } from "@/components/dashboard/top-nav"
import { WelcomeHeader } from "@/components/dashboard/welcome-header"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { StatsOverview } from "@/components/dashboard/stats-overview"
import { AIAssistant } from "@/components/dashboard/ai-assistant"
import { RecentNotes } from "@/components/dashboard/recent-notes"
import { HabitsOverview } from "@/components/dashboard/habits-overview"
import { CalendarOverview } from "@/components/dashboard/calendar-overview"
import { LearningProgress } from "@/components/dashboard/learning-progress"
import { ActivityFeed } from "@/components/dashboard/activity-feed"
import { AIInsights } from "@/components/dashboard/ai-insights"

export default function Dashboard() {
  return (
    <div className="relative min-h-screen">
      {/* Neural Network Background */}
      <div 
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/neural-brain-bg.png')" }}
      />
      <div className="fixed inset-0 bg-gradient-to-br from-black/60 via-black/40 to-black/50" />
      
      <div className="relative z-10">
        <Sidebar />
        
        <div className="pl-16 transition-all duration-300">
          <TopNav />
          
          <main className="p-6">
            <WelcomeHeader />
            <QuickActions />
            
            {/* AI Assistant and Habits */}
            <div className="grid gap-6 lg:grid-cols-3">
              <AIAssistant />
              <div className="lg:col-span-1">
                <HabitsOverview />
              </div>
            </div>
            
            {/* Notes and Calendar */}
            <div className="mt-6 grid gap-6 lg:grid-cols-2">
              <RecentNotes />
              <CalendarOverview />
            </div>
            
            {/* Learning, Activity, Insights */}
            <div className="mt-6 grid gap-6 lg:grid-cols-3">
              <LearningProgress />
              <ActivityFeed />
              <AIInsights />
            </div>

            {/* Stats moved to bottom */}
            <div className="mt-6">
              <StatsOverview />
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
