"use client"

import { Calendar as CalendarIcon, Clock, MapPin, Plus } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"
import { useState } from "react"

const initialEvents = [
  {
    id: 1,
    title: "Team Standup",
    time: "9:00 AM",
    duration: "30 min",
    location: "Zoom",
    color: "from-chart-1 to-chart-1/60",
  },
  {
    id: 2,
    title: "Design Review",
    time: "11:00 AM",
    duration: "1 hour",
    location: "Conference Room A",
    color: "from-chart-2 to-chart-2/60",
  },
  {
    id: 3,
    title: "Lunch with Sarah",
    time: "12:30 PM",
    duration: "1 hour",
    location: "Cafe Central",
    color: "from-chart-3 to-chart-3/60",
  },
  {
    id: 4,
    title: "Product Planning",
    time: "3:00 PM",
    duration: "2 hours",
    location: "Room 204",
    color: "from-chart-4 to-chart-4/60",
  },
]

const days = ["S", "M", "T", "W", "T", "F", "S"]
const currentDay = new Date().getDay()

export function CalendarOverview() {
  const [selectedDay, setSelectedDay] = useState(currentDay)
  const events = initialEvents

  return (
    <CollapsibleCard
      title="Today's Schedule"
      icon={<CalendarIcon className="h-5 w-5 text-violet-400" />}
      glowColor="purple"
      badge={<span className="ml-2 text-xs text-muted-foreground">{events.length} events</span>}
      rightAction={
        <button 
          onClick={(e) => e.stopPropagation()}
          className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground"
        >
          <Plus className="h-4 w-4" />
        </button>
      }
    >
      <div className="p-4">
        <div className="mb-4 flex justify-between rounded-lg bg-white/5 p-2">
          {days.map((day, index) => (
            <button
              key={index}
              onClick={() => setSelectedDay(index)}
              className={`flex h-8 w-8 items-center justify-center rounded-lg text-xs font-medium transition-all duration-200 ${
                index === selectedDay
                  ? "bg-gradient-to-br from-primary to-primary/60 text-primary-foreground shadow-lg shadow-primary/20"
                  : "text-muted-foreground hover:bg-white/10 hover:text-foreground"
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {events.map((event) => (
            <div
              key={event.id}
              className="group flex gap-3 rounded-lg border border-white/10 bg-white/5 p-3 transition-all hover:bg-white/10 hover:scale-[1.02] cursor-pointer"
            >
              <div className={`h-full w-1 rounded-full bg-gradient-to-b ${event.color}`} />
              <div className="flex-1">
                <h4 className="text-sm font-medium text-foreground">{event.title}</h4>
                <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {event.time} - {event.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {event.location}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </CollapsibleCard>
  )
}
