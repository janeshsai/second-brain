"use client"

import { Activity, FileText, Target, GraduationCap, Bot } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"

const activities = [
  {
    id: 1,
    type: "note",
    icon: FileText,
    title: "Created note",
    description: "Project Planning Meeting Notes",
    time: "2 hours ago",
    color: "text-chart-1",
    bgColor: "bg-chart-1/20",
  },
  {
    id: 2,
    type: "habit",
    icon: Target,
    title: "Completed habit",
    description: "Morning Meditation - 14 day streak!",
    time: "5 hours ago",
    color: "text-chart-2",
    bgColor: "bg-chart-2/20",
  },
  {
    id: 3,
    type: "learning",
    icon: GraduationCap,
    title: "Finished lesson",
    description: "Neural Networks Basics - ML Fundamentals",
    time: "Yesterday",
    color: "text-chart-4",
    bgColor: "bg-chart-4/20",
  },
  {
    id: 4,
    type: "ai",
    icon: Bot,
    title: "AI interaction",
    description: "Generated weekly summary report",
    time: "Yesterday",
    color: "text-primary",
    bgColor: "bg-primary/20",
  },
  {
    id: 5,
    type: "habit",
    icon: Target,
    title: "Completed habit",
    description: "Read 30 Minutes - 7 day streak!",
    time: "2 days ago",
    color: "text-chart-2",
    bgColor: "bg-chart-2/20",
  },
]

export function ActivityFeed() {
  return (
    <CollapsibleCard
      title="Recent Activity"
      icon={<Activity className="h-5 w-5 text-chart-5" />}
      rightAction={
        <button 
          onClick={(e) => e.stopPropagation()}
          className="text-xs text-primary hover:underline"
        >
          View All
        </button>
      }
    >
      <div className="divide-y divide-white/10">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="flex items-start gap-3 p-4 transition-colors hover:bg-white/5"
          >
            <div className={`rounded-lg ${activity.bgColor} p-2`}>
              <activity.icon className={`h-4 w-4 ${activity.color}`} />
            </div>
            <div className="flex-1">
              <p className="text-sm text-foreground">
                <span className="font-medium">{activity.title}</span>
              </p>
              <p className="text-sm text-muted-foreground">{activity.description}</p>
            </div>
            <span className="text-xs text-muted-foreground">{activity.time}</span>
          </div>
        ))}
      </div>
    </CollapsibleCard>
  )
}
