"use client"

import { Sparkles, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CollapsibleCard } from "./collapsible-card"

const suggestions = [
  "What tasks should I focus on today?",
  "Summarize my notes from this week",
  "Create a study plan for my current courses",
  "Show me my habit trends",
]

export function AIAssistant() {
  return (
    <CollapsibleCard
      title="AI Assistant"
      icon={<Sparkles className="h-5 w-5 text-cyan-400" />}
      glowColor="cyan"
      className="col-span-full lg:col-span-2"
    >
      <div className="p-4">
        <p className="mb-4 text-xs text-muted-foreground">Ask anything in your Second Brain</p>
        
        <div className="relative mb-4">
          <input
            type="text"
            placeholder="Ask me anything about your notes, habits, or goals..."
            className="h-12 w-full rounded-lg border border-white/10 bg-white/5 pl-4 pr-12 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <Button
            size="icon"
            className="absolute right-1.5 top-1/2 h-9 w-9 -translate-y-1/2"
          >
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion}
              className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3 py-1.5 text-xs text-cyan-300 transition-colors hover:border-cyan-400/50 hover:bg-cyan-500/20 hover:text-cyan-200"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>
    </CollapsibleCard>
  )
}
