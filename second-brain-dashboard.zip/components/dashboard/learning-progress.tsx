"use client"

import { GraduationCap, Play, BookOpen } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"
import { useState } from "react"

const initialPaths = [
  {
    id: 1,
    title: "Machine Learning Fundamentals",
    progress: 68,
    totalLessons: 24,
    completedLessons: 16,
    lastStudied: "2 hours ago",
    color: "from-chart-1 to-chart-1/60",
  },
  {
    id: 2,
    title: "Advanced TypeScript",
    progress: 45,
    totalLessons: 18,
    completedLessons: 8,
    lastStudied: "Yesterday",
    color: "from-chart-2 to-chart-2/60",
  },
  {
    id: 3,
    title: "System Design Interview Prep",
    progress: 32,
    totalLessons: 15,
    completedLessons: 5,
    lastStudied: "3 days ago",
    color: "from-chart-4 to-chart-4/60",
  },
]

export function LearningProgress() {
  const [paths, setPaths] = useState(initialPaths)
  const [hoveredPath, setHoveredPath] = useState<number | null>(null)

  const continueLesson = (id: number) => {
    setPaths(paths.map(p => 
      p.id === id 
        ? { 
            ...p, 
            completedLessons: Math.min(p.completedLessons + 1, p.totalLessons),
            progress: Math.min(Math.round(((p.completedLessons + 1) / p.totalLessons) * 100), 100),
            lastStudied: "Just now"
          } 
        : p
    ))
  }

  return (
    <CollapsibleCard
      title="Learning Progress"
      icon={<GraduationCap className="h-5 w-5 text-chart-4" />}
      rightAction={
        <button 
          onClick={(e) => e.stopPropagation()}
          className="text-xs text-primary hover:underline"
        >
          View All
        </button>
      }
    >
      <div className="divide-y divide-white/10">
        {paths.map((path) => (
          <div
            key={path.id}
            className="p-4 transition-colors hover:bg-white/5"
            onMouseEnter={() => setHoveredPath(path.id)}
            onMouseLeave={() => setHoveredPath(null)}
          >
            <div className="mb-2 flex items-start justify-between">
              <h4 className="text-sm font-medium text-foreground">{path.title}</h4>
              <button 
                onClick={() => continueLesson(path.id)}
                className={`flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary/60 text-primary-foreground transition-all duration-200 ${
                  hoveredPath === path.id ? "scale-110 shadow-lg shadow-primary/30" : ""
                }`}
              >
                <Play className="h-3 w-3" />
              </button>
            </div>

            <div className="mb-2 flex items-center gap-2 text-xs text-muted-foreground">
              <BookOpen className="h-3 w-3" />
              <span>
                {path.completedLessons}/{path.totalLessons} lessons
              </span>
              <span>-</span>
              <span>Last studied {path.lastStudied}</span>
            </div>

            <div className="flex items-center gap-3">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${path.color} transition-all duration-500`}
                  style={{ width: `${path.progress}%` }}
                />
              </div>
              <span className="text-xs font-medium text-muted-foreground">
                {path.progress}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </CollapsibleCard>
  )
}
