"use client"

import { useState, ReactNode } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"

type GlowColor = "cyan" | "magenta" | "purple" | "blue" | "green"

interface CollapsibleCardProps {
  title: string
  icon: ReactNode
  iconColor?: string
  badge?: ReactNode
  rightAction?: ReactNode
  children: ReactNode
  defaultExpanded?: boolean
  className?: string
  glowColor?: GlowColor
}

const glowStyles: Record<GlowColor, { border: string; shadow: string; iconBg: string; headerGradient: string }> = {
  cyan: {
    border: "border-cyan-500/30 hover:border-cyan-400/50",
    shadow: "hover:shadow-[0_0_30px_rgba(0,212,255,0.15)]",
    iconBg: "bg-cyan-500/20",
    headerGradient: "from-cyan-500/10 to-transparent",
  },
  magenta: {
    border: "border-pink-500/30 hover:border-pink-400/50",
    shadow: "hover:shadow-[0_0_30px_rgba(255,0,255,0.15)]",
    iconBg: "bg-pink-500/20",
    headerGradient: "from-pink-500/10 to-transparent",
  },
  purple: {
    border: "border-violet-500/30 hover:border-violet-400/50",
    shadow: "hover:shadow-[0_0_30px_rgba(139,92,246,0.15)]",
    iconBg: "bg-violet-500/20",
    headerGradient: "from-violet-500/10 to-transparent",
  },
  blue: {
    border: "border-blue-500/30 hover:border-blue-400/50",
    shadow: "hover:shadow-[0_0_30px_rgba(59,130,246,0.15)]",
    iconBg: "bg-blue-500/20",
    headerGradient: "from-blue-500/10 to-transparent",
  },
  green: {
    border: "border-emerald-500/30 hover:border-emerald-400/50",
    shadow: "hover:shadow-[0_0_30px_rgba(16,185,129,0.15)]",
    iconBg: "bg-emerald-500/20",
    headerGradient: "from-emerald-500/10 to-transparent",
  },
}

export function CollapsibleCard({
  title,
  icon,
  badge,
  rightAction,
  children,
  defaultExpanded = true,
  className,
  glowColor = "cyan",
}: CollapsibleCardProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded)
  const glow = glowStyles[glowColor]

  return (
    <div
      className={cn(
        "rounded-xl border bg-white/5 backdrop-blur-xl transition-all duration-300",
        glow.border,
        glow.shadow,
        className
      )}
    >
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={cn(
          "relative flex w-full items-center justify-between overflow-hidden rounded-t-xl border-b border-white/10 p-4 text-left transition-colors hover:bg-white/5"
        )}
      >
        <div className={cn("absolute inset-0 bg-gradient-to-r opacity-50", glow.headerGradient)} />
        <div className="relative flex items-center gap-3">
          <div className={cn("rounded-lg p-2", glow.iconBg)}>
            {icon}
          </div>
          <h3 className="font-semibold text-foreground">{title}</h3>
          {badge}
        </div>
        <div className="relative flex items-center gap-2">
          {rightAction}
          {isExpanded ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </button>

      <div
        className={cn(
          "grid transition-all duration-300 ease-in-out",
          isExpanded ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        )}
      >
        <div className="overflow-hidden">{children}</div>
      </div>
    </div>
  )
}
