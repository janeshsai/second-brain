"use client"

import { Sparkles, TrendingUp, Brain, Lightbulb, Zap } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"

const insights = [
  {
    id: 1,
    icon: TrendingUp,
    title: "Productivity Peak",
    description: "You're most productive between 9-11 AM. Consider scheduling deep work during this time.",
    color: "text-chart-2",
    bgColor: "bg-chart-2/20",
  },
  {
    id: 2,
    icon: Brain,
    title: "Habit Consistency",
    description: "Your meditation streak is at 14 days! You're building a strong routine.",
    color: "text-chart-4",
    bgColor: "bg-chart-4/20",
  },
  {
    id: 3,
    icon: Lightbulb,
    title: "Learning Suggestion",
    description: "Based on your notes, you might enjoy 'Deep Learning Specialization'.",
    color: "text-chart-3",
    bgColor: "bg-chart-3/20",
  },
  {
    id: 4,
    icon: Zap,
    title: "Quick Win",
    description: "Complete 2 more habits today to achieve your weekly goal.",
    color: "text-chart-1",
    bgColor: "bg-chart-1/20",
  },
]

export function AIInsights() {
  return (
    <CollapsibleCard
      title="AI Insights"
      icon={<Sparkles className="h-5 w-5 text-primary" />}
      badge={
        <span className="ml-2 rounded-full bg-primary/20 px-2 py-0.5 text-xs font-medium text-primary">
          4 new
        </span>
      }
    >
      <div className="divide-y divide-white/10">
        {insights.map((insight) => (
          <div
            key={insight.id}
            className="flex items-start gap-3 p-4 transition-colors hover:bg-white/5 cursor-pointer"
          >
            <div className={`rounded-lg ${insight.bgColor} p-2`}>
              <insight.icon className={`h-4 w-4 ${insight.color}`} />
            </div>
            <div>
              <h4 className="text-sm font-medium text-foreground">{insight.title}</h4>
              <p className="mt-0.5 text-sm text-muted-foreground">{insight.description}</p>
            </div>
          </div>
        ))}
      </div>
    </CollapsibleCard>
  )
}
