"use client"

import { useEffect, useState } from "react"
import { Sparkles } from "lucide-react"

export function WelcomeHeader() {
  const [greeting, setGreeting] = useState("Good morning")
  const [currentTime, setCurrentTime] = useState("")
  const [currentDate, setCurrentDate] = useState("")

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const hour = now.getHours()

      if (hour < 12) setGreeting("Good morning")
      else if (hour < 17) setGreeting("Good afternoon")
      else setGreeting("Good evening")

      setCurrentTime(
        now.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })
      )
      setCurrentDate(
        now.toLocaleDateString("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric",
        })
      )
    }

    updateTime()
    const interval = setInterval(updateTime, 60000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="mb-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            {greeting}, <span className="bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">Alex</span>
          </h1>
          <p className="mt-1 text-muted-foreground">
            {currentDate} · {currentTime}
          </p>
        </div>
        <div className="mt-3 sm:mt-0">
          <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 backdrop-blur-sm">
            <Sparkles className="h-4 w-4 text-chart-2" />
            <p className="text-sm text-muted-foreground">
              You&apos;ve completed <span className="font-semibold text-chart-2">73%</span> of your weekly goals
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
