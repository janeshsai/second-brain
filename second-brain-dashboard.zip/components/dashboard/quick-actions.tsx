"use client"

import { FileText, Target, Bookmark, Calendar, Bot } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

const actions = [
  { icon: FileText, label: "New Note", color: "text-chart-1", bgColor: "bg-chart-1/20", hoverBg: "hover:bg-chart-1/30" },
  { icon: Target, label: "New Habit", color: "text-chart-2", bgColor: "bg-chart-2/20", hoverBg: "hover:bg-chart-2/30" },
  { icon: Bookmark, label: "Add Bookmark", color: "text-chart-3", bgColor: "bg-chart-3/20", hoverBg: "hover:bg-chart-3/30" },
  { icon: Calendar, label: "Create Event", color: "text-chart-4", bgColor: "bg-chart-4/20", hoverBg: "hover:bg-chart-4/30" },
  { icon: Bot, label: "Ask AI", color: "text-primary", bgColor: "bg-primary/20", hoverBg: "hover:bg-primary/30" },
]

export function QuickActions() {
  const [activeAction, setActiveAction] = useState<string | null>(null)

  return (
    <div className="mb-6">
      <div className="flex flex-wrap gap-2">
        {actions.map((action) => (
          <button
            key={action.label}
            onClick={() => setActiveAction(activeAction === action.label ? null : action.label)}
            className={cn(
              "flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2.5 text-sm font-medium transition-all duration-200 backdrop-blur-sm",
              activeAction === action.label 
                ? `${action.bgColor} border-transparent scale-105 shadow-lg`
                : `bg-white/5 ${action.hoverBg} hover:border-white/20 hover:scale-102`
            )}
          >
            <action.icon className={`h-4 w-4 ${action.color}`} />
            <span className="text-foreground">{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
