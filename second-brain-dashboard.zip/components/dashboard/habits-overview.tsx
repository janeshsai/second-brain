"use client"

import { useState } from "react"
import { Target, Flame, Check } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"

const initialHabits = [
  { id: 1, name: "Morning Meditation", streak: 14, completed: true },
  { id: 2, name: "Read 30 Minutes", streak: 7, completed: true },
  { id: 3, name: "Exercise", streak: 5, completed: false },
  { id: 4, name: "Journal Writing", streak: 21, completed: false },
  { id: 5, name: "Learn Spanish", streak: 3, completed: true },
]

export function HabitsOverview() {
  const [habits, setHabits] = useState(initialHabits)
  
  const toggleHabit = (id: number) => {
    setHabits(habits.map(h => 
      h.id === id ? { ...h, completed: !h.completed, streak: !h.completed ? h.streak + 1 : h.streak - 1 } : h
    ))
  }

  const completedCount = habits.filter((h) => h.completed).length
  const completionPercentage = Math.round((completedCount / habits.length) * 100)

  return (
    <CollapsibleCard
      title="Today's Habits"
      icon={<Target className="h-5 w-5 text-pink-400" />}
      glowColor="magenta"
      badge={
        <span className="ml-2 rounded-full bg-pink-500/20 px-2.5 py-1 text-xs font-medium text-pink-400">
          {completionPercentage}%
        </span>
      }
    >
      <div className="p-4">
        <div className="mb-4 h-2 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-pink-500 to-pink-500/60 transition-all duration-500"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>

        <div className="space-y-3">
          {habits.map((habit) => (
            <div
              key={habit.id}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 p-3 transition-all hover:bg-white/10"
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => toggleHabit(habit.id)}
                  className={`flex h-6 w-6 items-center justify-center rounded-md border-2 transition-all duration-200 ${
                    habit.completed
                      ? "border-pink-500 bg-pink-500 text-background scale-110"
                      : "border-white/20 hover:border-pink-500 hover:scale-105"
                  }`}
                >
                  {habit.completed && <Check className="h-4 w-4" />}
                </button>
                <span
                  className={`text-sm transition-all ${
                    habit.completed ? "text-muted-foreground line-through" : "text-foreground"
                  }`}
                >
                  {habit.name}
                </span>
              </div>
              <div className="flex items-center gap-1 text-xs text-chart-3">
                <Flame className="h-3 w-3" />
                <span>{habit.streak} days</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </CollapsibleCard>
  )
}
