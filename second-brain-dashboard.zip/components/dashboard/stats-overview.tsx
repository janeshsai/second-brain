"use client"

import { FileText, Target, Calendar, GraduationCap, Bookmark, MessageSquare, TrendingUp, TrendingDown } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

const stats = [
  {
    label: "Total Notes",
    value: "247",
    change: "+12",
    trend: "up",
    icon: FileText,
    color: "text-chart-1",
    bgColor: "bg-chart-1/20",
    gradient: "from-chart-1/20 to-chart-1/5",
  },
  {
    label: "Active Habits",
    value: "8",
    change: "+2",
    trend: "up",
    icon: Target,
    color: "text-chart-2",
    bgColor: "bg-chart-2/20",
    gradient: "from-chart-2/20 to-chart-2/5",
  },
  {
    label: "Upcoming Tasks",
    value: "15",
    change: "-3",
    trend: "down",
    icon: Calendar,
    color: "text-chart-3",
    bgColor: "bg-chart-3/20",
    gradient: "from-chart-3/20 to-chart-3/5",
  },
  {
    label: "Learning Progress",
    value: "68%",
    change: "+5%",
    trend: "up",
    icon: GraduationCap,
    color: "text-chart-4",
    bgColor: "bg-chart-4/20",
    gradient: "from-chart-4/20 to-chart-4/5",
  },
  {
    label: "Bookmarks Saved",
    value: "156",
    change: "+8",
    trend: "up",
    icon: Bookmark,
    color: "text-chart-5",
    bgColor: "bg-chart-5/20",
    gradient: "from-chart-5/20 to-chart-5/5",
  },
  {
    label: "AI Conversations",
    value: "34",
    change: "+4",
    trend: "up",
    icon: MessageSquare,
    color: "text-primary",
    bgColor: "bg-primary/20",
    gradient: "from-primary/20 to-primary/5",
  },
]

export function StatsOverview() {
  const [hoveredStat, setHoveredStat] = useState<string | null>(null)

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
      {stats.map((stat) => (
        <div
          key={stat.label}
          onMouseEnter={() => setHoveredStat(stat.label)}
          onMouseLeave={() => setHoveredStat(null)}
          className={cn(
            "group relative overflow-hidden rounded-xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl transition-all duration-300 cursor-pointer",
            hoveredStat === stat.label && "scale-105 border-white/20 shadow-lg"
          )}
        >
          <div className={cn(
            "absolute inset-0 bg-gradient-to-br opacity-0 transition-opacity duration-300",
            stat.gradient,
            hoveredStat === stat.label && "opacity-100"
          )} />
          
          <div className="relative z-10">
            <div className="flex items-center justify-between">
              <div className={`rounded-lg ${stat.bgColor} p-2 transition-transform duration-300 group-hover:scale-110`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
              <div className="flex items-center gap-1 text-xs">
                {stat.trend === "up" ? (
                  <TrendingUp className="h-3 w-3 text-chart-5" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-destructive" />
                )}
                <span className={stat.trend === "up" ? "text-chart-5" : "text-destructive"}>
                  {stat.change}
                </span>
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
