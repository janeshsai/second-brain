"use client"

import {
  LayoutDashboard,
  FileText,
  Bookmark,
  Target,
  Calendar,
  GraduationCap,
  Sparkles,
} from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "#", active: true },
  { icon: FileText, label: "Notes", href: "#" },
  { icon: Bookmark, label: "Bookmarks", href: "#" },
  { icon: Target, label: "Habits", href: "#" },
  { icon: Calendar, label: "Calendar", href: "#" },
  { icon: GraduationCap, label: "Learning Paths", href: "#" },
]

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-16 flex-col border-r border-white/10 bg-black/40 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-center border-b border-white/10">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/60">
          <Sparkles className="h-5 w-5 text-primary-foreground" />
        </div>
      </div>

      <nav className="flex flex-1 flex-col items-center gap-2 p-3">
        {navItems.map((item) => (
          <a
            key={item.label}
            href={item.href}
            title={item.label}
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-200",
              item.active
                ? "bg-primary/20 text-primary shadow-lg shadow-primary/20"
                : "text-muted-foreground hover:bg-white/10 hover:text-foreground"
            )}
          >
            <item.icon className="h-5 w-5" />
          </a>
        ))}
      </nav>
    </aside>
  )
}
