"use client"

import { FileText, Search, Plus, X } from "lucide-react"
import { CollapsibleCard } from "./collapsible-card"
import { useState } from "react"

const initialNotes = [
  {
    id: 1,
    title: "Project Planning Meeting Notes",
    excerpt: "Key decisions from today's sprint planning session...",
    date: "2 hours ago",
    tags: ["work", "planning"],
  },
  {
    id: 2,
    title: "Machine Learning Study Notes",
    excerpt: "Chapter 5: Neural networks and deep learning basics...",
    date: "Yesterday",
    tags: ["learning", "AI"],
  },
  {
    id: 3,
    title: "Book Review: Atomic Habits",
    excerpt: "Key takeaways from James Clear's bestselling book...",
    date: "2 days ago",
    tags: ["books", "habits"],
  },
  {
    id: 4,
    title: "Weekly Reflection Journal",
    excerpt: "Reflecting on wins and areas for improvement...",
    date: "3 days ago",
    tags: ["personal", "reflection"],
  },
]

export function RecentNotes() {
  const [notes, setNotes] = useState(initialNotes)
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)

  const filteredNotes = notes.filter(note => 
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    note.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const deleteNote = (id: number) => {
    setNotes(notes.filter(n => n.id !== id))
  }

  return (
    <CollapsibleCard
      title="Recent Notes"
      icon={<FileText className="h-5 w-5 text-cyan-400" />}
      glowColor="cyan"
      rightAction={
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          {isSearching ? (
            <input
              type="text"
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-7 w-32 rounded-md border border-white/10 bg-white/5 px-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              onClick={(e) => e.stopPropagation()}
            />
          ) : null}
          <button 
            onClick={(e) => { e.stopPropagation(); setIsSearching(!isSearching); setSearchQuery(""); }}
            className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground"
          >
            <Search className="h-4 w-4" />
          </button>
          <button className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground">
            <Plus className="h-4 w-4" />
          </button>
        </div>
      }
    >
      <div className="divide-y divide-white/10">
        {filteredNotes.map((note) => (
          <div
            key={note.id}
            className="group cursor-pointer p-4 transition-colors hover:bg-white/5"
          >
            <div className="mb-1 flex items-start justify-between">
              <h4 className="font-medium text-foreground">{note.title}</h4>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{note.date}</span>
                <button 
                  onClick={() => deleteNote(note.id)}
                  className="opacity-0 group-hover:opacity-100 rounded p-1 text-muted-foreground hover:bg-destructive/20 hover:text-destructive transition-all"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            </div>
            <p className="mb-2 line-clamp-1 text-sm text-muted-foreground">
              {note.excerpt}
            </p>
            <div className="flex gap-1.5">
              {note.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-white/10 px-2 py-0.5 text-xs text-muted-foreground"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </CollapsibleCard>
  )
}
